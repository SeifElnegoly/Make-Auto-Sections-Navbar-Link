const sections = Array.from(document.querySelectorAll('section'));
const navBar = document.getElementById('navbar__list');

function CreateItems() {
     for (var section of sections) {
          sectionName = section.getAttribute('data-nav');
          sectionLink = section.getAttribute('id');
          listItem = document.createElement('li');

          listItem.innerHTML = `<a class='menu__link' href='#${sectionLink}'>${sectionName}</a>`;

          navBar.appendChild(listItem);
     }
}


function SectionView(element) {
     let sectionPostion = element.getBoundingClientRect();
     return (sectionPostion.top >= 0);
}

function toggleClass() {
     for (var section of sections) {
          if (SectionView(section)) {
               if (!section.classList.contains('your-active-class')) {
                    section.classList.add('your-active-class');
               } else {
                    section.classList.remove('your-active-class');
               }
          }
     }
}


CreateItems();

document.addEventListener('scroll' , toggleClass)
